# Gritpack

Gritpack is a headless, polyglot package manager and package server, comparable
in purpose to npm. It also provides a compiler-facing API for fast module and
transitive file-graph queries.

**Author:** Alexander R. Croft · source files carry AGPL-3.0-or-later notices;
prebuilt binaries are distributed under the bundled proprietary [LICENSE](LICENSE)

The same core serves the embedded library, `gritpack` command-line client, and
server. A self-hosted server may use local disk; a hosted server may use
S3-compatible Capsule storage. Private hubs use mutual TLS. Public hubs may
explicitly allow anonymous reads while retaining mTLS for every mutation.

Package names may be global (`bobs-package`) or scoped
(`@bob/bobs-package`). Packages are public to every client accepted by their
server. Private distribution is provided by running a private Gritpack server,
not by a private-package flag.

## Install Gritpack

Official prebuilt releases are published from the public
[`frogfishio/homebrew-gritpack`](https://github.com/frogfishio/homebrew-gritpack)
distribution repository. The small Formula-only tap is
[`frogfishio/homebrew-gritpack-tap`](https://github.com/frogfishio/homebrew-gritpack-tap).
The private source repository is not needed to install Gritpack.

| Platform | Supported architecture | Recommended source |
|---|---|---|
| macOS | Apple Silicon (`arm64`) | Homebrew Formula |
| Debian and Ubuntu | `amd64`, `arm64` | Signed APT repository |
| RHEL, Rocky Linux, AlmaLinux, and Fedora | `x86_64`, `aarch64` | Signed RPM/DNF repository |
| Any supported platform | As listed above | Versioned archive from [GitHub Releases](https://github.com/frogfishio/homebrew-gritpack/releases) |

### Homebrew

```sh
brew tap frogfishio/gritpack-tap
brew trust --formula frogfishio/gritpack-tap/gritpack
brew install --formula frogfishio/gritpack-tap/gritpack
gritpack --version
```

If the legacy `frogfishio/gritpack` tap is already present, migrate explicitly:

```sh
brew untap --force frogfishio/gritpack
brew tap frogfishio/gritpack-tap
brew trust --formula frogfishio/gritpack-tap/gritpack
brew install --formula frogfishio/gritpack-tap/gritpack
```

Homebrew uninstalls the legacy-tap Formula during the forced untap; the final
command reinstalls the same released version from the lean tap.

### APT

```sh
sudo install -d -m 0755 /etc/apt/keyrings
curl -fsSLo /tmp/gritpack-repository.gpg \
  https://frogfishio.github.io/homebrew-gritpack/repository-signing-key.gpg
sudo install -m 0644 /tmp/gritpack-repository.gpg \
  /etc/apt/keyrings/gritpack.gpg
curl -fsSLo /tmp/gritpack.sources \
  https://frogfishio.github.io/homebrew-gritpack/gritpack.sources
sudo install -m 0644 /tmp/gritpack.sources \
  /etc/apt/sources.list.d/gritpack.sources
sudo apt update
sudo apt install gritpack
gritpack --version
```

### DNF or RPM

```sh
curl -fsSLo /tmp/gritpack.repo \
  https://frogfishio.github.io/homebrew-gritpack/gritpack.repo
sudo install -m 0644 /tmp/gritpack.repo \
  /etc/yum.repos.d/gritpack.repo
sudo dnf install gritpack
gritpack --version
```

APT and DNF authenticate the Frogfish repository metadata with its dedicated
OpenPGP key. macOS releases are Developer ID signed, timestamped, hardened, and
Apple-notarized. Versioned archives, Debian packages, RPMs, signed checksums,
and their detached signature can also be obtained directly from
[GitHub Releases](https://github.com/frogfishio/homebrew-gritpack/releases).

Detailed verification, upgrade, direct-download, compatibility, and
release-operator instructions are in [DISTRIBUTION.md](DISTRIBUTION.md).
The authoritative map of local, CI, Apple, OpenPGP, and S3 credential names is
in [CREDENTIALS.md](CREDENTIALS.md).

For a concise capability map and a fair comparison with npm and Cargo, start
with [FEATURES.md](FEATURES.md). The product boundary and current refinement
questions are defined in [PRODUCT_DEFINITION.md](PRODUCT_DEFINITION.md).

For client, compiler-integration, certificate, and hub startup instructions,
see [USER_GUIDE.md](USER_GUIDE.md).

For production deployment, administration, S3, private Cargo, backup, upgrade,
monitoring, and incident procedures, see
[OPERATIONS_MANUAL.md](OPERATIONS_MANUAL.md).
Frogfish project maintainers should use the explicit enrollment, Cargo,
publication, consumption, CI, and pilot checklist in
[FROGFISH_PRIVATE_REGISTRY_GUIDE.md](FROGFISH_PRIVATE_REGISTRY_GUIDE.md).

The Taxis/Residiuum integration boundary for polyglot module graphs and compiler
queries is defined in [GRAPH_INDEXING.md](GRAPH_INDEXING.md).

The supported read-only-first agent interface and its security boundary are
defined in [MCP_INTEGRATION.md](MCP_INTEGRATION.md).

The production public-registry boundary for `get.gritpack.org`, anonymous
package consumption, invitation-only publishing, deployment, and the future
`gritpack.org` website is defined in
[PUBLIC_REGISTRY.md](PUBLIC_REGISTRY.md).
The live bootstrap topology, qualification evidence, operating observations,
and prioritized hardening gaps are recorded in
[PUBLIC_REGISTRY_AS_BUILT.md](PUBLIC_REGISTRY_AS_BUILT.md).
The isolated Frogfish private registry running beside it, including its Cargo
integration and mixed public/private qualification, is recorded in
[PRIVATE_REGISTRY_AS_BUILT.md](PRIVATE_REGISTRY_AS_BUILT.md).

## Current Status

The core package lifecycle is implemented:

- deterministic Capsule packing and strict validation
- certificate enrollment with client-local keys, local operator codes, or
  persisted administrator-issued account-bound invitations
- zero-configuration anonymous reads from `get.gritpack.org:443`, plus explicit
  public-read server mode with authenticated mutations
- separate package and management mTLS listeners
- npm-style scoped names and publication ownership
- immutable filesystem Capsule storage, plus optional S3-compatible storage
  for native packages and the private Cargo registry
- Residiuum alpha-3 Heap metadata, indexed RQL queries, and flat-store migration
- publish, search, metadata lookup, Capsule download, and installation
- owner deprecation/yank and administrator quarantine lifecycle controls
- project init/add, installed graph listing/explanation, outdated reporting,
  synchronization/repair, strict verification, and project diagnosis
- named package-server profiles plus unambiguous local credential discovery
- verified shared content-addressed Capsule caching with corrupt-object repair
- cache status/verification and dry-run-first deterministic pruning
- bounded parallel graph downloads and integrity-bound resumable transfers
- SemVer dependency resolution and deterministic lock files
- preferred private-server lookup with default fallback and source-pinned lock v3
- administrator account/scope lifecycle with certificate-attributed audit, and
  ordinary self-service operations
- remove, update, and direct-dependency upgrade
- Ratatouille telemetry selected through `GRITPACK_TELEMETRY_FILTER`

Ranked headless discovery is implemented over a persisted Residiuum inverted
candidate index, with explainable lexical-v1 results for human, JSON, and
NDJSON clients. A local read-only stdio MCP adapter exposes search, package
inspection, version listing, resolution preview and explanation, and verified
installed-file inventory through the same application services.

Automation can select the stable `gritpack/error@1` JSON failure envelope and
categorized exit codes documented in [CLI_ERRORS.md](CLI_ERRORS.md).

The exact pre-semantic compiler substrate now exists: lock v3 roots, a verified
resolved package/file universe, conservative dialect candidate indexes, and a
deterministic mechanical Residiuum draft projection. The remaining core blocker
is the semantic module graph. Gritpack has the Residiuum graph dependency and a
frozen ownership boundary, but Taxis does
not yet expose the supported resolved-module SDK needed to define the
projection without duplicating module semantics.

## Build

```bash
cd gritpack
cargo build
cargo test

# Hosted/server build with the S3 Capsule backend:
cargo build --features s3
```

From the repository root:

```bash
make test      # unit tests
make ci        # fmt + clippy + unit tests + e2e lifecycle
make e2e       # enroll → pack → serve → publish → search → install
```

CI is defined in `.github/workflows/ci.yml`. The e2e script lives at
`scripts/e2e-lifecycle.sh` (ephemeral certs and free ports).

Inspect the initial command surface with:

```bash
cargo run -- --help
cargo run -- serve --help
```

For a private Rust registry, keep crates.io as Cargo's default and add the hub
as a named source:

```bash
gritpack cargo setup --profile office --registry company
gritpack cargo doctor --registry company
cargo publish --registry company
```

## Hub Interfaces

The default listeners are:

- package API: `127.0.0.1:7443`, mTLS using the package-client CA
- management API: `127.0.0.1:7444`, mTLS using the management-client CA
- optional enrollment API: `127.0.0.1:7445`, server-authenticated TLS
- Cargo sparse registry/API: `127.0.0.1:7446`, server-authenticated TLS with
  short-lived bearer credentials minted through the package mTLS API

The management listener accepts administrator certificates and exposes health,
account creation, and scope assignment. The package listener exposes ordinary
self-service account inspection, credential revocation, and unowned-scope
claiming. The matching CLI commands are `whoami`, `revoke`, `claim-scope`,
`add-user`, `users`, `user`, `suspend-user`, `reactivate-user`, `delete-user`,
`assign-scope`, `scopes`, `scope`, `unassign-scope`, `audit-log`, `yank`,
`deprecate`, and `quarantine`; there is no built-in GUI.

Use `gritpack <command> --help` for the environment-backed runtime parameters.

## Proposals Under Review

[REPOSITORY_PROTOCOL.md](REPOSITORY_PROTOCOL.md) specifies a proposed static
repository format for publishing the same immutable Capsules from local
directories, S3, ordinary HTTPS sites, and GitHub-driven deployments without
requiring a running hub. It is deliberately marked for critique and is not yet
part of the implemented product contract.

[GLOBAL_INSTALLATION.md](GLOBAL_INSTALLATION.md) specifies the companion
user-global application model: `gritpack install`, managed commands in
`~/.gritpack/bin`, untrusted explicit external sources, and an admin-curated
official installation catalogue whose admissions bind exact Capsule digests.

[CARGO_REGISTRY_INTEGRATION.md](CARGO_REGISTRY_INTEGRATION.md) specifies the
private Cargo-registry adapter: Cargo remains the resolver and builder, while
Gritpack stores canonical Capsules and serves deterministic `.crate` and sparse
index projections. crates.io remains the untouched default Cargo source.

## Extensions

Startup peer synchronization is an experimental federation extension built
with `--features peer-sync`; it is not the core multi-server model. Captain and
software-lifecycle work are also extensions, recorded separately in
[SOFTWARE_INSTALLATION_EXPLORATION.md](SOFTWARE_INSTALLATION_EXPLORATION.md).
